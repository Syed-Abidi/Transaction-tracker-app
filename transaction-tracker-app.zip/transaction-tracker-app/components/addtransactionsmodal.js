// basic imports
import {
  ImageBackground,
  Pressable,
  TextInput,
  View,
  Alert,
  StyleSheet,
  Text,
  Image,
  TouchableOpacity,
  Modal,
  ScrollView,
} from 'react-native';
import React, { useState, useLayoutEffect, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { Picker } from '@react-native-picker/picker'; // Import Picker for dropdown
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'; // Import icons

export default function TransactionModal({
  visible,
  onClose,
  transactions,
  setTransactions,
}) {
  const [isIncome, setIsIncome] = useState(true);
  const [addTrans, setTrans] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(''); // Track selected category

  const numberstrokes = (input) => {
    setTrans(input);
  };

  function delinput(index) {
  setTransactions((prevTransactions) =>
    prevTransactions.filter((_, i) => i !== index)
  );
}


  const incomeCategories = [
    { key: 'business', label: 'Business', icon: 'briefcase' },
    { key: 'job', label: 'Job', icon: 'account-tie' },
    { key: 'other', label: 'Other', icon: 'dots-horizontal' },
  ];

  const expenseCategories = [
    { key: 'food', label: 'Food', icon: 'silverware-fork-knife' },
    { key: 'gaming', label: 'Gaming', icon: 'gamepad-variant' },
    { key: 'transport', label: 'Transport', icon: 'bus' },
    { key: 'education', label: 'Education', icon: 'school' },
    { key: 'misc', label: 'Misc', icon: 'dots-horizontal' },
  ];

  const handleCategorySelect = (category) => {
    setSelectedCategory(category);
  };

  function incomeButtonHandler(income) {
    if (!income || isNaN(income) || !selectedCategory) return;
    setTransactions((prevTransactions) => [
      ...prevTransactions,
      { type: 'income', value: parseFloat(income), category: selectedCategory },
    ]);
    setTrans('');
    setSelectedCategory('');
  }

  function expenseButtonHandler(expense) {
    if (!expense || isNaN(expense) || !selectedCategory) return;
    setTransactions((prevTransactions) => [
      ...prevTransactions,
      {
        type: 'expense',
        value: parseFloat(expense),
        category: selectedCategory,
      },
    ]);
    setTrans('');
    setSelectedCategory('');
  }

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}>
      <View style={styles.modalContainer}>
        <View style={styles.modalView}>
          {/* Toggle Buttons */}
          <View style={styles.toggleButtons}>
            <TouchableOpacity
              style={[styles.toggleButton, isIncome && styles.activeButton]}
              onPress={() => setIsIncome(true)}>
              <Text style={styles.toggleButtonText}>Income (+)</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleButton, !isIncome && styles.activeButton]}
              onPress={() => setIsIncome(false)}>
              <Text style={styles.toggleButtonText}>Expense (-)</Text>
            </TouchableOpacity>
          </View>

          {/* Category Icons */}
          <View style={styles.iconContainer}>
            {(isIncome ? incomeCategories : expenseCategories).map(
              (category) => (
                <TouchableOpacity
                  key={category.key}
                  style={[
                    styles.categoryIcon,
                    selectedCategory === category.key &&
                      styles.selectedCategory,
                  ]}
                  onPress={() => handleCategorySelect(category.key)}>
                  <Icon
                    name={category.icon}
                    size={30}
                    color="#4169e1"
                    style={styles.selectionicons}
                  />
                  <Text style={styles.iconLabel}>{category.label}</Text>
                </TouchableOpacity>
              )
            )}
          </View>

          {/* Input Section */}
          <View style={styles.inputSection}>
            <TextInput
              keyboardType="number-pad"
              style={styles.transinput}
              onChangeText={numberstrokes}
              value={addTrans}
            />
            <TouchableOpacity
              style={isIncome ? styles.addIncomeButton : styles.addLossButton}
              onPress={() =>
                isIncome
                  ? incomeButtonHandler(addTrans)
                  : expenseButtonHandler(addTrans)
              }>
              <Text style={styles.modalText}>Add</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.closemodal} onPress={onClose}>
            <Text style={styles.closemodaltext}>Confirm</Text>
          </TouchableOpacity>

          <View style={styles.inputList}>
            <ScrollView style={styles.transactionList}>
              {transactions.map((item, index) => (
                <Text
                  key={index}
                  style={
                    item.type === 'income'
                      ? styles.incomeText
                      : styles.expenseText
                  }>
                  {item.type === 'income'
                    ? `+ ${item.value}`
                    : `- ${item.value}`}{' '}
                  <Icon
                    name={
                      [...incomeCategories, ...expenseCategories].find(
                        (cat) => cat.key === item.category
                      )?.icon || 'dots-horizontal'
                    }
                    size={20}
                    color={item.type === 'income' ? 'green' : 'red'}
                  />
                  <TouchableOpacity
                    style={styles.delentry}
                    onPress={() => delinput(index)}>
                    <Image
                      style={styles.delimg}
                      source={require('../assets/trash.png')}
                    />
                  </TouchableOpacity>
                </Text>
              ))}
            </ScrollView>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    width: 300,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
  },
  toggleButtons: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  toggleButton: {
    padding: 10,
    marginHorizontal: 10,
    borderRadius: 10,
    backgroundColor: '#e0e0e0',
  },
  activeButton: {
    backgroundColor: '#4169e1',
  },
  toggleButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  modalText: {
    fontSize: 15,
    fontWeight: 'bold',
  },
  addIncomeButton: {
    backgroundColor: '#5bb450',
    padding: 15,
    borderRadius: 10,
    marginLeft: 5,
    marginBottom: 15,
  },
  addLossButton: {
    backgroundColor: 'lightpink',
    padding: 15,
    borderRadius: 10,
    marginLeft: 5,
    marginBottom: 15,
  },

  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  transinput: {
    padding: 10,
    borderWidth: 2,
    marginBottom: 15,
    borderRadius: 10,
  },

  inputSection: {
    flexDirection: 'row',
  },
  closemodal: {
    backgroundColor: '#4169e1',
    padding: 15,
    borderRadius: 10,
  },
  closemodaltext: {
    fontSize: 15,
    fontWeight: 'bold',
  },

  transactionList: {
    marginTop: 20,
    width: '100%',
    maxHeight: 100, // Set a maximum height for better scrolling experience
    padding: 10,
    borderWidth: 2,
    borderColor: 'cyan', // Cyan border
    backgroundColor: '#d3d3d3', // Light grey background
    borderRadius: 10,
    alignItems: 'center', // Centers items horizontally
    justifyContent: 'center', // Centers items vertically,
    flex: 1,
  },
  incomeText: {
    color: 'green', // Green text for income
    fontWeight: 'bold',
    fontSize: 20,
    marginBottom: 5,
  },
  expenseText: {
    color: '#ff007f', // Light pink text for expenses
    fontWeight: 'bold',
    fontSize: 20,
    marginBottom: 5,
    marginLeft: 6,
  },
  inputList: { width: 250, flexDirection: 'row' },
  delentry: {
    left: 70,
    color: 'black',
  },
  delimg: {
    width: 25,
    height: 25,
    bottom: 0,
    top: -19,
    position: 'absolute',
    right: 1,
  },
  iconContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    margin: 10,
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },

  selectionicons: {
    margin: 5,
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconLabel: {
    margin: 5,
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
