// basic imports
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import React, { useState, useLayoutEffect, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'; // Import icons

import TransactionModal from '../components/addtransactionsmodal.js'

export default function Homescreen() {
  const [netToday, setNetToday] = useState(0); // Sum of today's transactions
  const [modalVisible, setModalVisible] = useState(false);
  const [modalTransactions, setModalTransactions] = useState([]); // Transactions in the modal
  const [displayTransactions, setDisplayTransactions] = useState([]); // Copy of transactions to display in Homescreen

  useEffect(() => {
    const total = displayTransactions.reduce((sum, transaction) => {
      return transaction.type === 'income'
        ? sum + transaction.value
        : sum - transaction.value;
    }, 0);
    setNetToday(total); // Update the net sum
  }, [displayTransactions]);

  const handleModalClose = () => {
    setModalVisible(false); // Close the modal
    setDisplayTransactions((prev) => [...prev, ...modalTransactions]); // Add modal transactions to the display array
    setModalTransactions([]); // Clear modal transactions after copying
  };

  const navigator = useNavigation();
  useLayoutEffect(() => {
    navigator.setOptions({ headerShown: false });
  }, [navigator]);

  const incomeCategories = [
    { key: 'business', icon: 'briefcase-outline' },
    { key: 'job', icon: 'account-tie-outline' },
    { key: 'other', icon: 'dots-horizontal' },
  ];

  const expenseCategories = [
    { key: 'food', icon: 'food-outline' },
    { key: 'gaming', icon: 'gamepad-variant-outline' },
    { key: 'transport', icon: 'car-outline' },
    { key: 'education', icon: 'school-outline' },
    { key: 'misc', icon: 'dots-horizontal' },
  ];

  return (
    <View style={styles.container}>
      {/* Add Transaction Button */}
      <View style={styles.transButtonContainer}>
        <TouchableOpacity style={styles.transButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.transButtonText}>Add Transaction</Text>
        </TouchableOpacity>
        <TransactionModal
          visible={modalVisible}
          onClose={handleModalClose} // Custom close handler
          transactions={modalTransactions}
          setTransactions={setModalTransactions}
        />
      </View>

      {/* Today's Transactions */}
      <View style={styles.todayStransaction}>
        <View style={styles.todayStransHeader}>
          <Text style={styles.todayStransText}>Today's Transactions</Text>
          <Text style={styles.netTodayText}>Net Today: {netToday}</Text>
        </View>
        <View style={styles.hr}></View>
      </View>

      <ScrollView style={styles.transactionList}>
        {displayTransactions.map((item, index) => (
          <View key={index} style={styles.transactionItem}>
            <Text
              style={
                item.type === 'income' ? styles.incomeText : styles.expenseText
              }
            >
              {item.type === 'income' ? `+ ${item.value}` : `- ${item.value}`}
            </Text>
            <Icon
              name={
                [...incomeCategories, ...expenseCategories].find(
                  (cat) => cat.key === item.category
                )?.icon || 'dots-horizontal'
              }
              size={20}
              color={item.type === 'income' ? 'green' : 'red'}
              style={styles.categoryIcon}
            />
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  // Add Transaction Button
  transButtonContainer: {
    alignItems: 'center',
    marginTop: 50,
  },
  transButton: {
    backgroundColor: '#4169e1',
    borderRadius: 15,
    padding: 20,
  },
  transButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },

  // Today's Transactions Header
  todayStransaction: {
    marginTop: 20,
  },
  todayStransHeader: {
    flexDirection: 'row',
    flex: 1,
  },
  todayStransText: {
    marginLeft: 5,
    fontSize: 15,
   fontWeight: 'bold',
  },
  netTodayText: {
    left: 40,
    color: '#4169e1',
    fontSize: 18,
  },
  hr: {
    borderBottomColor: 'black',
    borderBottomWidth: StyleSheet.hairlineWidth,
    marginTop: 5,
    marginBottom: 5,
  },

  // Transactions List
  transactionList: {
    paddingHorizontal: 20,
    marginTop: 10,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  incomeText: {
    color: 'green',
    fontSize: 16,
    fontWeight: 'bold',
  },
  expenseText: {
    color: '#ff007f',
    fontSize: 16,
    fontWeight: 'bold',
  },
  categoryIcon: {
    margin: 5,
    width: 10,
  },
});
