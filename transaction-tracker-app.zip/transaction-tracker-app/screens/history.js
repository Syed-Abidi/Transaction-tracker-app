// basic imports
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import React, { useState, useLayoutEffect, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'; // Import icons

export default function HistoryScreen() {
  const navigator = useNavigation();
  useLayoutEffect(() => {
    navigator.setOptions({ headerShown: false });
  }, [navigator]);

  const [selectedTab, setSelectedTab] = useState('daily'); // Default to 'daily'

  // Sample transactions
  const transactions = {
    daily: [
      { id: 1, type: 'income', category: 'job', value: 50 },
      { id: 2, type: 'expense', category: 'food', value: 20 },
    ],
    weekly: [
      { id: 3, type: 'income', category: 'business', value: 200 },
      { id: 4, type: 'expense', category: 'transport', value: 50 },
    ],
    monthly: [
      { id: 5, type: 'income', category: 'job', value: 1500 },
      { id: 6, type: 'expense', category: 'education', value: 500 },
    ],
  };

  // Category icons mapping
  const categoryIcons = {
    job: 'account-tie-outline',
    food: 'food-outline',
    business: 'briefcase-outline',
    transport: 'car-outline',
    education: 'school-outline',
    gaming: 'gamepad-variant-outline',
  };

  // Filter transactions based on selectedTab
  const displayedTransactions = transactions[selectedTab];

  return (
      <View style={styles.container}>
      {/* Tab Section */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tabButton,
            selectedTab === 'daily' && styles.activeTab,
          ]}
          onPress={() => setSelectedTab('daily')}
        >
          <Text
            style={[
              styles.tabText,
              selectedTab === 'daily' && styles.activeTabText,
            ]}
          >
            Daily
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabButton,
            selectedTab === 'weekly' && styles.activeTab,
          ]}
          onPress={() => setSelectedTab('weekly')}
        >
          <Text
            style={[
              styles.tabText,
              selectedTab === 'weekly' && styles.activeTabText,
            ]}
          >
            Weekly
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabButton,
            selectedTab === 'monthly' && styles.activeTab,
          ]}
          onPress={() => setSelectedTab('monthly')}
        >
          <Text
            style={[
              styles.tabText,
              selectedTab === 'monthly' && styles.activeTabText,
            ]}
          >
            Monthly
          </Text>
        </TouchableOpacity>
      </View>
      {/* Transactions Section */}
      <ScrollView style={styles.transactionList}>
        {displayedTransactions.map((transaction) => (
          <View key={transaction.id} style={styles.transactionItem}>
            <Text
              style={transaction.type === 'income' ? styles.incomeText : styles.expenseText}
            >
              {transaction.type === 'income' ? `+ ${transaction.value}` : `- ${transaction.value}`}
            </Text>
            <Icon
              name={categoryIcons[transaction.category] || 'dots-horizontal'}
              size={20}
              color={transaction.type === 'income' ? 'green' : 'red'}
              style={styles.categoryIcon}
            />
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  tabContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#4169e1',
    paddingVertical: 10,
  },
  tabButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
  },
  activeTab: {
    backgroundColor: '#f5f5f5',
  },
  tabText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  transactionList: {
    paddingHorizontal: 20,
    marginTop: 10,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  incomeText: {
    color: 'green',
    fontSize: 16,
    fontWeight: 'bold',
  },
  expenseText: {
    color: '#ff007f',
    fontSize: 16,
    fontWeight: 'bold',
  },
  categoryIcon: {
    margin: 5,
    width: 20,
  },
   activeTabText: {
    color: '#4169e1', // Blue text for the active tab
  },
});

